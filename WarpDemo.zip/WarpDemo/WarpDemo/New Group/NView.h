//
//  NView.h
//  WZLearnOpenGL
//
//  Created by admin on 18/10/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NView : UIView

@end
