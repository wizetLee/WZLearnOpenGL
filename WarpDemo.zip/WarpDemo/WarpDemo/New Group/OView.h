//
//  0View.h
//  WarpDemo
//
//  Created by admin on 23/10/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "WZGLView.h"

@interface OView : WZGLView

@property (nonatomic, assign) GLuint index0;
@property (nonatomic, assign) GLuint texture1;

@end
