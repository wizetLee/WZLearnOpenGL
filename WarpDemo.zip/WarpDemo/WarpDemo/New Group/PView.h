//
//  PView.h
//  WarpDemo
//
//  Created by admin on 24/10/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "WZGLView.h"

@interface PView : WZGLView

///个别
@property (nonatomic, strong) GLProgram *program1;
@property (nonatomic, assign) GLuint buffer1;
@property (nonatomic, assign) GLuint dataBuffer1;
@property (nonatomic, assign) GLuint texture1;
@property (nonatomic, assign) GLuint index1;

@property (nonatomic, assign) GLuint texture2;

@end
