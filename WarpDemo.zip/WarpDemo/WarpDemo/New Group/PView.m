
//
//  PView.m
//  WarpDemo
//
//  Created by admin on 24/10/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "PView.h"
#define Column (100)
#define SizeOFVectorTextureCoordinate (Column * 2/*position :x, y*/ * 2/*texture: x, y*/ * 2/*两个点*/ + 4*2)
#define SizeOfIndices  (Column * 3/*位置*/ * 2/*个数*/)


@interface PView()
{
    float new_arrBuffer[SizeOFVectorTextureCoordinate];
    int new_indices[SizeOfIndices];
    
    CGFloat targetY;//计算非线性方程极大值的依据   0~1
    CGFloat targetX;//计算偏移程度的依据
    CGFloat lastLocationX;
    BOOL updating;
    
    CGFloat weight;
}

@property (nonatomic, strong) UISlider *slider;
@end

@implementation PView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        weight = 0.0;
        [self normalData];
        _slider = [[UISlider alloc] init];
        _slider.frame = CGRectMake(0.0, frame.size.height - 44.0, frame.size.width, 44.0);
        [_slider addTarget:self action:@selector(slider:) forControlEvents:UIControlEventValueChanged];
        [self addSubview:_slider];
    }
    return self;
}

- (void)slider:(UISlider *)sender {
    weight = sender.value * 0.05;
}

- (void)normalData {
    targetY = 0.0;
    targetX = 0.0;
    updating = false;
    lastLocationX = 0.0;
    
    {
        int tmpIndex = 0;
        int stride = 4;//只保存顶点坐标xy 纹理坐标xy
        CGFloat yfloat = (Column * 1.0);
        CGFloat multiple = 2.0;
        float *arr = (float *)new_arrBuffer;
        ///顶点坐标 纹理坐标
        for (int j = 0; j < Column + 1; j++) {
            for (int i = 0; i < 2; i++) {//2个点为顶点坐标 另外两个点为纹理坐标
                CGFloat positionX = i;
                CGFloat positionY =  j / yfloat;
                
                CGFloat textureX = i;
                CGFloat texturey = j / yfloat;
                
                arr[tmpIndex + 0] = positionX * multiple - 1.0;
                arr[tmpIndex + 1] = positionY * multiple - 1.0;
                
                arr[tmpIndex + 2] = textureX;
                arr[tmpIndex + 3] = 1.0 - texturey;//texturey; //纹理坐标跟position坐标Y翻转
                tmpIndex += stride;
            }
        }
        stride = 6;
        tmpIndex = 0;
        ///索引
        for (int i = 0; i < Column; i++) {
            new_indices[tmpIndex + 0] = 1 + i*2;
            new_indices[tmpIndex + 1] = 3 + i*2;
            new_indices[tmpIndex + 2] = 2 + i*2;
            new_indices[tmpIndex + 3] = 2 + i*2;
            new_indices[tmpIndex + 4] = 0 + i*2;
            new_indices[tmpIndex + 5] = 1 + i*2;
            tmpIndex += stride;
        }
    }
    [self gestures];
    [self update];
}

- (void)gestures {
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)];
    [self addGestureRecognizer:pan];
}

- (void)pan:(UIPanGestureRecognizer *)pan {
    if (updating) { return;}
    updating = true;
    ///区分方向
    if (pan.state == UIGestureRecognizerStateBegan) {
        lastLocationX = [pan locationInView:pan.view].x;//拾获最初的角标
    } else if (pan.state == UIGestureRecognizerStateChanged) {
        CGFloat result = [pan translationInView:pan.view].x - lastLocationX;//方向判别
        lastLocationX = [pan translationInView:pan.view].x;//更新位置
        if (result > 0) {
            //向右
            targetX = 0.003 + weight;
        } else if (result < 0) {
            //向左
            targetX = -0.003 - weight;
        } else {
            //不变
            targetX = 0.0;
        }
        
        /**
         translation.x < 0    向左
         translation.y < 0    向上
         **/
        CGPoint curPoint = [pan locationInView:pan.view];
        targetY =  curPoint.y / self.bounds.size.height;//iOS 设备坐标下的0~1.0
        
        //数据范围
        if (targetY < 0) {targetY = 0.0;}
        if (targetY > 1) {targetY = 1.0;}
        
    } else if (pan.state == UIGestureRecognizerStateEnded) {
        
    }
    [self update];
    updating = false;
}

- (NSString *)program0TextureSourceName {
    return @"che1.jpg";
}

- (void)setupProgramAttachment{
    [self setupProgram1];
    
    //开启所有缓存的混融模式
//    glEnable(GL_BLEND);//开启混融模式
    //    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);//设置混融模式  dst: 1 - 1 = 0
    
//    glBlendFuncSeparate(GL_ONE, GL_ONE_MINUS_DST_COLOR, GL_SRC_ALPHA, GL_ONE_MINUS_DST_ALPHA);
    
}

- (void)setupProgram1 {
    NSArray *attributeStrs = @[@"position", @"textureCoordinate", @"secondTextureCoordinate"];
    _program1 = [[GLProgram alloc] initWithVertexShaderFilename:@"shaderColourModulationV" fragmentShaderFilename:@"shaderColourModulationF"];
    [self setupProgram:_program1 attributeArray:attributeStrs];
   
    
    [_program1 use];
    glGenBuffers(1, &_buffer1);
    glGenBuffers(1, &_index1);
    
    
    GLuint sourceImageUniform = [_program1 uniformIndex:@"sourceImage"];
    GLuint secondSourceImageUniform = [_program1 uniformIndex:@"secondSourceImage"];
    //    GLuint texture1Uniform = [_program0 uniformIndex:@"imageTexture"];
    //加载纹理
    
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(_texture0, GL_TEXTURE0);
//    setupTexture(@"che1.jpg", &_texture1, GL_TEXTURE1);
    
    setupTexture(@"74172016103114541058969337.jpg", &_texture2, GL_TEXTURE3);
    
    glUniform1i(sourceImageUniform, 2);///配置纹理
    glUniform1i(secondSourceImageUniform, 3);///配置纹理
}

- (void)renderProgramAttachment {
    [self renderProgram1];
}

- (void)renderProgram1 {
    [_program1 use];
    glBindBuffer(GL_ARRAY_BUFFER, _buffer1);
    glVertexAttribPointer([_program1 attributeIndex:@"position"], 2, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 4, NULL);
    glVertexAttribPointer([_program1 attributeIndex:@"textureCoordinate"], 2, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 4, (float *)NULL + 2);
    glVertexAttribPointer([_program1 attributeIndex:@"secondTextureCoordinate"], 2, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 4, (float *)NULL + 2);
    [self enableAttribute:_program1 attributeArray:@[@"position", @"textureCoordinate", @"secondTextureCoordinate"]];
    
    glUniform1f([_program1 uniformIndex:@"alpha"], 1.0);
    glUniform1i([_program1 uniformIndex:@"blendType"], 33);
    [self dataChange];
}

- (void)dataChange {
    {//--------------point : 计算偏移量
        CGFloat tmpTargetY = 1.0 - targetY;//取反得到纹理坐标系中的点
        
        ///手势对坐标的压缩量
        float xCompreess = 0.0;
        //计算偏移值
        int tmpIndex = 0;
        int stride = 4;//只保存顶点坐标xy 纹理坐标xy
        for (int j = 0; j < Column + 1; j++) {
            for (int i = 0; i < 2; i++) {//2个点为顶点坐标 另外两个点为纹理坐标
                //将[0.0, 1.0]区间映射到[-PI, PI]区间上
                xCompreess = j / (Column * 1.0);//0~1.0
                xCompreess = xCompreess * 2 * M_PI ;//0~2PI
                xCompreess = xCompreess - M_PI;//-PI~PI
                
                CGFloat tmpY = tmpTargetY;
                tmpY = tmpY * 2 * M_PI;//映射到[-PI, PI]区间上
                tmpY = tmpY - M_PI;
                
                //作差 得到 图形偏移
                //NSLog(@"图形偏移~%f", cos(xCompreess - tmpY) + 1);
                
                CGFloat degree = xCompreess - tmpY;
                if (degree > M_PI) {
                    degree = M_PI;
                } else if (degree < -M_PI) {
                    degree = -M_PI;
                }
                
                CGFloat tmpComPress = sqrt((cos(degree) + 1)) * targetX;
                
                new_arrBuffer[tmpIndex + 0] = new_arrBuffer[tmpIndex + 0] + tmpComPress;//只修改X坐标  根据j代入相应的非线性方程中 得到偏移量
                tmpIndex += stride;
            }
        }
    }
    
    ///打印数据
    //    for(int i = 0 ; i < sizeOfArr ; i++) {if (i % 4 == 0) {printf("\n"); }
    //        printf("%f ", arrBuffer[i]);
    //    }//    printf("\n--------------\n");
    //    for(int i = 0 ; i < column * 3/*位置*/ * 2/*个数*/ ; i++) {if (i % 3 == 0) { printf("\n"); }
    //        printf("%d ", _indices[i]);
    //    }printf("\n--------------\n");
    
    
    glBindBuffer(GL_ARRAY_BUFFER, _buffer1);
    glBufferData(GL_ARRAY_BUFFER, sizeof(float)*SizeOFVectorTextureCoordinate , new_arrBuffer, GL_DYNAMIC_DRAW);
    
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _index1);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(int)*SizeOfIndices, new_indices, GL_STATIC_DRAW);
    
    glDrawElements(GL_TRIANGLES, SizeOfIndices, GL_UNSIGNED_INT, 0);//绘制
}

@end
