//
//  TView.m
//  WarpDemo
//
//  Created by admin on 26/10/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "TView.h"
#import "GLProgram.h"
#include <OpenGLES/ES2/gl.h>
#include <OpenGLES/ES2/glext.h>

#define targetImageName @"24472016071513372170498279.png"
//@"74172016103114541058969337.jpg"
//@"15952016071513373913911529.png" 
//@"24472016071513372170498279.png"

@interface TView()

@property (nonatomic, strong) CAEAGLLayer *eaglLayer;
@property (nonatomic, strong) EAGLContext *context;

@property (nonatomic, strong) GLProgram *program0;
@property (nonatomic, strong) GLProgram *program1;


@property (nonatomic, assign) GLuint colorRenderBuffer;
@property (nonatomic, assign) GLuint colorFrameBuffer;

@property (nonatomic, assign) GLuint renderToTextureFrameBuffer;
@property (nonatomic, assign) GLuint needRenderTexture;//目标纹理句柄

@property (nonatomic, assign) GLuint texture0ForImage;//图片纹理句柄

@property (nonatomic, assign) GLuint vbo0;
@property (nonatomic, assign) GLuint vbo1;

@property (nonatomic, strong) UIImageView *imageView;

@end

@implementation TView

void dataProviderReleaseCallbackFunc (void *info, const void *data, size_t size)
{
    free((void *)data);
}

+ (Class)layerClass {
    return [CAEAGLLayer class];
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0, -100, 100, 100)];
        _imageView.backgroundColor = [UIColor yellowColor];
        [self addSubview:_imageView];
        
        CGSize imageSize = [UIImage imageNamed:targetImageName].size;
        CGSize screenSize = [UIScreen mainScreen].bounds.size;
        CGSize fitSize = imageSize;
        
        //适配屏幕
        if (imageSize.height != 0.0) {
            //宽高比
            CGFloat whRate = imageSize.width / imageSize.height;
            //宽>高
            if (whRate > 1.0) {
                if (imageSize.width > screenSize.width) {
                    fitSize.width = screenSize.width;
                    fitSize.height = screenSize.width / imageSize.width * imageSize.height;
                }
                
                if (fitSize.height > screenSize.height) {
                    fitSize.width = screenSize.height / fitSize.height * fitSize.width;
                    fitSize.height = screenSize.height;
                }
            } else {
                //宽<高
                
                if (imageSize.height > screenSize.height) {
                    fitSize.height = screenSize.height;
                    fitSize.width = screenSize.height / imageSize.height * imageSize.width;
                }
                
                if (fitSize.width > screenSize.width) {
                    fitSize.height = screenSize.width / fitSize.width * fitSize.height;
                    fitSize.width = screenSize.width;
                }
            }
        }
        //更改画布尺寸
        self.frame = CGRectMake(0.0, 0.0, fitSize.width, fitSize.height);
        
        [self setupLayer];
        [self setupContext];
        [self setupPrograms];
        [self update];
        
    }
    return self;
}

- (void)setupContext {
    self.context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES2];
    [EAGLContext setCurrentContext:self.context];
}

- (void)setupLayer {
    [self setContentScaleFactor:[[UIScreen mainScreen] scale]];
    self.eaglLayer = (CAEAGLLayer *)self.layer;
    self.eaglLayer.opaque = true;
    // 设置描绘属性，在这里设置不维持渲染内容以及颜色格式为 RGBA8
    self.eaglLayer.drawableProperties = [NSDictionary dictionaryWithObjectsAndKeys:
                                         [NSNumber numberWithBool:false], kEAGLDrawablePropertyRetainedBacking, kEAGLColorFormatRGBA8, kEAGLDrawablePropertyColorFormat, nil];
}

///启用数组内的顶点属性
- (void)enableAttribute:(GLProgram *)program attributeArray:(NSArray <NSString *>*)attributeArray {
    if ([attributeArray count]) {
        for (NSString *attributeName in attributeArray) {
            glEnableVertexAttribArray([program attributeIndex:attributeName]);
        }
    }
}

- (void)setupPrograms {
    _program0 = [[GLProgram alloc] initWithVertexShaderFilename:@"shaderDefaultV" fragmentShaderFilename:@"shaderDefaultF"];
    NSArray *attributeStrs = @[@"position", @"textureCoordinate"];
    [self setupProgram:_program0 attributeArray:attributeStrs];
    
    _program1 = [[GLProgram alloc] initWithVertexShaderFilename:@"shaderDefaultV" fragmentShaderFilename:@"shaderDefaultF"];
    [self setupProgram:_program1 attributeArray:attributeStrs];
}

- (void)setupProgram:(GLProgram *)program attributeArray:(NSArray <NSString *>*)attributeArray {
    
    if ([attributeArray count]) {
        for (NSString *attributeName in attributeArray) {
            [program addAttribute:attributeName];
        }
    }
    
    if (!program.initialized)
    {
        if (![program link]) {
            NSString *progLog = [program programLog];
            NSLog(@"Program link log: %@", progLog);
            NSString *fragLog = [program fragmentShaderLog];
            NSLog(@"Fragment shader compile log: %@", fragLog);
            NSString *vertLog = [program vertexShaderLog];
            NSLog(@"Vertex shader compile log: %@", vertLog);
            program = nil;
            NSAssert(NO, @"Filter shader link failed");
        }
    }
}

- (void)update {
    [EAGLContext setCurrentContext:_context];
    
    glDeleteFramebuffers(1, &_colorFrameBuffer);
    _colorFrameBuffer = 0;
    glDeleteRenderbuffers(1, &_colorRenderBuffer);
    _colorRenderBuffer = 0;
    glDeleteRenderbuffers(1, &_renderToTextureFrameBuffer);
    _renderToTextureFrameBuffer = 0;

    glGenRenderbuffers(1, &_colorRenderBuffer);
    glBindRenderbuffer(GL_RENDERBUFFER, _colorRenderBuffer);
    [_context renderbufferStorage:GL_RENDERBUFFER fromDrawable:self.eaglLayer];
    glGenFramebuffers(1, &_colorFrameBuffer);
    glBindFramebuffer(GL_FRAMEBUFFER, _colorFrameBuffer);
    //渲染缓存 关联到 _colorFrameBuffer
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                              GL_RENDERBUFFER, _colorRenderBuffer);
    
    CGSize imageSize = [UIImage imageNamed:targetImageName].size;
#warning 图片的像素尺寸
    CGSize size = CGSizeMake(imageSize.width, imageSize.height);
//    CGSize size = CGSizeMake(imageSize.width * scale, imageSize.height * scale);
//    CGFloat scale = [UIScreen mainScreen].scale;
//    size = CGSizeMake(self.frame.size.width * scale, self.frame.size.height *scale);
  //图片尺寸
    glGenTextures(1, &_needRenderTexture);
    glBindTexture(GL_TEXTURE_2D, _needRenderTexture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, size.width, size.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
    glBindTexture(GL_TEXTURE_2D, 0);
    
    glGenFramebuffers(1, &_renderToTextureFrameBuffer);
    glBindFramebuffer(GL_FRAMEBUFFER, _renderToTextureFrameBuffer);
    ///纹理 关联到 _renderToTextureFrameBuffer   当_renderToTextureFrameBuffer drawArray之后 _needRenderTexture才会有该帧缓存的内容
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, _needRenderTexture, 0);
    
    [self render];
}



- (void)viewPort {
    //视图放大倍数
    CGFloat scale = [UIScreen mainScreen].scale;
    //设置视口
    glViewport(0.0
               , 0.0
               , self.frame.size.width * scale
               , self.frame.size.height * scale);//没问题
}

- (void)render {
/////////////////////////////////////离屏渲染
    [_program0 use];
    glBindFramebuffer(GL_FRAMEBUFFER, _renderToTextureFrameBuffer);
    
    glClearColor(1.0, 1.0, 1.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT);
    [self viewPort];
    
    CGFloat scale = 1.0;
    GLfloat attrArr[] =
    {
        1.0 * scale, 1.0 * scale, 0,     1.0, 0.0,
        1.0 * scale, -1.0 * scale, 0,     1.0, 1.0,
        -1.0 * scale, -1.0 * scale, 0,    0.0, 1.0,
        -1.0 * scale, -1.0 * scale, 0,    0.0, 1.0,
        -1.0 * scale, 1.0 * scale, 0,     0.0, 0.0,
        1.0 * scale, 1.0 * scale, 0,     1.0, 0.0,
    };
    //数据配置
    glGenBuffers(1, &_vbo0);
    glBindBuffer(GL_ARRAY_BUFFER, _vbo0);
    glBufferData(GL_ARRAY_BUFFER, sizeof(attrArr), attrArr, GL_STATIC_DRAW);
    
    [self enableAttribute:_program0 attributeArray:@[@"position", @"textureCoordinate"]];
    glVertexAttribPointer([_program0 attributeIndex:@"position"], 3, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 5, NULL);
    glVertexAttribPointer([_program0 attributeIndex:@"textureCoordinate"], 2, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 5, (GLfloat *)NULL + 3);
    
    CGImageRef spriteImage = [UIImage imageNamed:targetImageName].CGImage;
    
#warning 图片的像素尺寸
    size_t width = CGImageGetWidth(spriteImage);
    size_t height = CGImageGetHeight(spriteImage);
    GLubyte *spriteData = (GLubyte *) calloc(width * height * 4, sizeof(GLubyte));
    CGContextRef spriteContext = CGBitmapContextCreate(spriteData, width, height, 8, width*4,
                                                       CGImageGetColorSpace(spriteImage), kCGImageAlphaPremultipliedLast);
    //绘制为像素大小没问题啊.....
    CGContextDrawImage(spriteContext, CGRectMake(0, 0, width, height), spriteImage);

    glGenTextures(1, &_texture0ForImage);
    glBindTexture(GL_TEXTURE_2D, _texture0ForImage);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    float fw = width, fh = height;

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, fw, fh, 0, GL_RGBA, GL_UNSIGNED_BYTE, spriteData);
    glBindTexture(GL_TEXTURE_2D, 0);
    CGContextRelease(spriteContext);
    free(spriteData);
    
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, _texture0ForImage);
    glUniform1i([_program0 uniformIndex:@"imageTexture"], 2);
    glDrawArrays(GL_TRIANGLES, 0, 6);
    
////////////////////////////////////当前屏幕渲染
    [_program1 use];
    glBindFramebuffer(GL_FRAMEBUFFER, _colorFrameBuffer);
    glClearColor(1.0, 1.0, 1.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT);
    [self viewPort];
    
    //不必改Y坐标  因为第一个帧缓存已经修改过Y坐标
    GLfloat attrArr2[] =
    {
        1.0 * scale, 1.0 * scale, 0,     1.0, 1.0,
        1.0 * scale, -1.0 * scale, 0,     1.0, 0.0,
        -1.0 * scale, -1.0 * scale, 0,    0.0, 0.0,
        -1.0 * scale, -1.0 * scale, 0,    0.0, 0.0,
        -1.0 * scale, 1.0 * scale, 0,     0.0, 1.0,
        1.0 * scale, 1.0 * scale, 0,     1.0, 1.0,
    };
    //数据配置
    glGenBuffers(1, &_vbo1);
    glBindBuffer(GL_ARRAY_BUFFER, _vbo1);
    glBufferData(GL_ARRAY_BUFFER, sizeof(attrArr2), attrArr2, GL_STATIC_DRAW);
    
    [self enableAttribute:_program1 attributeArray:@[@"position", @"textureCoordinate"]];
    ///更新着色器属性
    glVertexAttribPointer([_program1 attributeIndex:@"position"], 3, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 5, NULL);
    glVertexAttribPointer([_program1 attributeIndex:@"textureCoordinate"], 2, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 5, (GLfloat *)NULL + 3);
    
    glActiveTexture(GL_TEXTURE3);
    glBindTexture(GL_TEXTURE_2D, _needRenderTexture);///帧缓存的纹理渲染缓冲区中
    glUniform1i([_program1 uniformIndex:@"imageTexture"], 3);

    glDrawArrays(GL_TRIANGLES, 0, 6);
    
    
    
    
    
    
    
    
    
    
    glBindRenderbuffer(GL_RENDERBUFFER, _colorRenderBuffer);
    [_context presentRenderbuffer:GL_RENDERBUFFER];
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    glFinish();
    //取出图片
    CGSize s = [UIImage imageNamed:targetImageName].size;
    glBindFramebuffer(GL_FRAMEBUFFER, _renderToTextureFrameBuffer);

#warning 图片的像素尺寸
    CGSize size = CGSizeZero;
    size = CGSizeMake(s.width, s.height);//就是需要图片的size
    CGImageRef imageRef = [self newCGImageFromFramebufferContentsWithTargetImageSize:size];
    UIImage *image = [UIImage imageWithCGImage:imageRef];
    _imageView.image = image;
    _imageView.contentMode = UIViewContentModeScaleAspectFit;
}

///来自于GPUImage的代码
- (CGImageRef)newCGImageFromFramebufferContentsWithTargetImageSize:(CGSize)size
{
    __block CGImageRef cgImageFromBytes;
    NSUInteger totalBytesForImage = (int)size.width * (int)size.height * 4;///图片所需要的字节数
    // It appears that the width of a texture must be padded out to be a multiple of 8 (32 bytes) if reading from it using a texture cache
    //如果使用纹理缓存读取纹理，纹理的宽度必须被填充为8(32字节)的倍数
    
    GLubyte *rawImagePixels;
    CGDataProviderRef dataProvider = NULL;
    glBindFramebuffer(GL_FRAMEBUFFER, _renderToTextureFrameBuffer);
//    glViewport(0, 0, (int)size.width, (int)size.height);
    rawImagePixels = (GLubyte *)malloc(totalBytesForImage);
    ///手动分配内存并且读取
    
    ///read 图片的size
    glReadPixels(0, 0, (int)size.width, (int)size.height, GL_RGBA, GL_UNSIGNED_BYTE, rawImagePixels);
    dataProvider = CGDataProviderCreateWithData(NULL, rawImagePixels, totalBytesForImage, dataProviderReleaseCallbackFunc);///根据指针、字节，在内存中获取data

    CGColorSpaceRef defaultRGBColorSpace = CGColorSpaceCreateDeviceRGB();//颜色空间
    ///从数据中提取图片
    cgImageFromBytes = CGImageCreate((int)size.width, (int)size.height, 8, 32, 4 * (int)size.width, defaultRGBColorSpace, kCGBitmapByteOrderDefault | kCGImageAlphaLast, dataProvider, NULL, NO, kCGRenderingIntentDefault);
    
    //释放
    CGDataProviderRelease(dataProvider);
    CGColorSpaceRelease(defaultRGBColorSpace);
    
    return cgImageFromBytes;
}

@end
