//
//  TView.m
//  WarpDemo
//
//  Created by admin on 26/10/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "WView.h"
#import "GLProgram.h"
#include <OpenGLES/ES2/gl.h>
#include <OpenGLES/ES2/glext.h>

#define targetImageName @"che3.jpg"
//@"24472016071513372170498279.png"
//@"Simulator Screen Shot - iPhone 6s - 2017-10-25 at 07.55.44.png"
//@"74172016103114541058969337.jpg"
//@"15952016071513373913911529.png"
//@"24472016071513372170498279.png"

@interface WView()

@property (nonatomic, strong) CAEAGLLayer *eaglLayer;
@property (nonatomic, strong) EAGLContext *context;

@property (nonatomic, assign) GLuint sourceImageTexture;//input  texture

@property (nonatomic, assign) GLuint outputFrameBuffer;  //outputFramebuffer
@property (nonatomic, assign) GLuint outputFrameBufferTexture;// output texture

@property (nonatomic, strong) GLProgram *program0;// GPU programs
@property (nonatomic, strong) GLProgram *program1;// GPU programs

///显示
@property (nonatomic, assign) GLuint displayRenderbuffer;//
@property (nonatomic, assign) GLuint displayFramebuffer;// for render in screen

//显示的只需要当前view的像素大小
@property (nonatomic, assign) GLuint vbo0;
@property (nonatomic, assign) GLuint vbo1;//VBO

@property (nonatomic, strong) UIImageView *imageView;//touch in screen then show the picture

@end

@implementation WView


//缩小渲染缓存的原理  设置比较小的帧缓存  然后渲染上去？？？

void zzzdataProviderReleaseCallbackFunc (void *info, const void *data, size_t size)
{
    free((void *)data);
}

+ (Class)layerClass {
    return [CAEAGLLayer class];
}

- (CGSize)fitSizeComparisonWithScreenBound:(CGSize)targetSize {
    CGSize screenSize = [UIScreen mainScreen].bounds.size;
    CGSize imageSize = targetSize;
    CGSize fitSize = targetSize;
    if (imageSize.height != 0.0) {            //宽高比
        CGFloat whRate = imageSize.width / imageSize.height;
        //宽>高
        if (whRate > 1.0) {
            if (imageSize.width > screenSize.width) {
                fitSize.width = screenSize.width;
                fitSize.height = screenSize.width / imageSize.width * imageSize.height;
                
            }
            if (fitSize.height > screenSize.height) {
                fitSize.width = screenSize.height / fitSize.height * fitSize.width;
                fitSize.height = screenSize.height;
                
            }
        } else {
            
            //宽<高
            if (imageSize.height > screenSize.height) {
                fitSize.height = screenSize.height;
                fitSize.width = screenSize.height / imageSize.height * imageSize.width;
            }
            if (fitSize.width > screenSize.width) {
                fitSize.height = screenSize.width / fitSize.width * fitSize.height;
                fitSize.width = screenSize.width;
            }
        }
    }
    
    return fitSize;
}

- (void)setupContext {
    self.context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES2];
    [EAGLContext setCurrentContext:self.context];
}

- (void)setupLayer {
    [self setContentScaleFactor:[[UIScreen mainScreen] scale]];
    self.eaglLayer = (CAEAGLLayer *)self.layer;
    self.eaglLayer.opaque = true;
    // 设置描绘属性，在这里设置不维持渲染内容以及颜色格式为 RGBA8
    self.eaglLayer.drawableProperties = [NSDictionary dictionaryWithObjectsAndKeys:
                                         [NSNumber numberWithBool:false], kEAGLDrawablePropertyRetainedBacking, kEAGLColorFormatRGBA8, kEAGLDrawablePropertyColorFormat, nil];
}

///启用数组内的顶点属性
- (void)enableAttribute:(GLProgram *)program attributeArray:(NSArray <NSString *>*)attributeArray {
    if ([attributeArray count]) {
        for (NSString *attributeName in attributeArray) {
            glEnableVertexAttribArray([program attributeIndex:attributeName]);
        }
    }
}

- (void)setupProgram:(GLProgram *)program attributeArray:(NSArray <NSString *>*)attributeArray {
    
    if ([attributeArray count]) {
        for (NSString *attributeName in attributeArray) {
            [program addAttribute:attributeName];
        }
    }
    
    if (!program.initialized)
    {
        if (![program link]) {
            NSString *progLog = [program programLog];
            NSLog(@"Program link log: %@", progLog);
            NSString *fragLog = [program fragmentShaderLog];
            NSLog(@"Fragment shader compile log: %@", fragLog);
            NSString *vertLog = [program vertexShaderLog];
            NSLog(@"Vertex shader compile log: %@", vertLog);
            program = nil;
            NSAssert(NO, @"Filter shader link failed");
        }
    }
}

#pragma mark - 变更的类型
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0, -100, 100, 100)];
        _imageView.backgroundColor = [UIColor yellowColor];
        [self addSubview:_imageView];
        
        CGSize imageSize = [UIImage imageNamed:targetImageName].size;
        CGSize fitSize = imageSize;
        fitSize = [self fitSizeComparisonWithScreenBound:fitSize];
        self.frame = CGRectMake(0.0, 0.0, fitSize.width, fitSize.height);
        
        [self setupLayer];
        [self setupContext];
        [self setupPrograms];
        [self update];
        
    }
    return self;
}


- (void)setupPrograms {
    _program0 = [[GLProgram alloc] initWithVertexShaderFilename:@"shaderDefaultV" fragmentShaderFilename:@"shaderDefaultF"];
    NSArray *attributeStrs = @[@"position", @"textureCoordinate"];
    [self setupProgram:_program0 attributeArray:attributeStrs];
    
    _program1 = [[GLProgram alloc] initWithVertexShaderFilename:@"shaderDefaultV" fragmentShaderFilename:@"shaderDefaultF"];
    [self setupProgram:_program1 attributeArray:attributeStrs];
}



- (void)update {
    [EAGLContext setCurrentContext:_context];
    
    ////create display framebuffer
    glDeleteFramebuffers(1, &_displayFramebuffer);
    _displayFramebuffer = 0;
    glDeleteRenderbuffers(1, &_displayRenderbuffer);
    _displayRenderbuffer = 0;
    
    [self setupImageTexture];
    [self setupOutputFrameBuffer];
    [self render];
}

///设置视口
- (void)viewPort {
    GLint backingWidth, backingHeight;
    //获取高度 宽度
    glGetRenderbufferParameteriv(GL_RENDERBUFFER, GL_RENDERBUFFER_WIDTH, &backingWidth);
    glGetRenderbufferParameteriv(GL_RENDERBUFFER, GL_RENDERBUFFER_HEIGHT, &backingHeight);
    glViewport(0.0, 0.0, backingWidth, backingHeight);
}

- (void)render {
    CGFloat scale = 1.0;
    //渲染到帧缓存当中
    [_program0 use];
    glBindFramebuffer(GL_FRAMEBUFFER, _outputFrameBuffer);
    glClearColor(0.0, 0.0, 0.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT);
    [self viewPort];
    CGSize pixelSize = [UIImage imageNamed:targetImageName].size;
#warning - 我的天 这个视口配置非常关键...
    glViewport(0.0, 0.0, pixelSize.width, pixelSize.height);
    
    GLfloat attrArr[] =
    {
        1.0 * scale, 1.0 * scale,      1.0, 0.0,
        1.0 * scale, -1.0 * scale,     1.0, 1.0,
        -1.0 * scale, -1.0 * scale,   0.0, 1.0,
        -1.0 * scale, -1.0 * scale,     0.0, 1.0,
        -1.0 * scale, 1.0 * scale,     0.0, 0.0,
        1.0 * scale, 1.0 * scale,    1.0, 0.0,
    };
    glGenBuffers(1, &_vbo0);
    glBindBuffer(GL_ARRAY_BUFFER, _vbo0);
    glBufferData(GL_ARRAY_BUFFER, sizeof(attrArr), attrArr, GL_STATIC_DRAW);
    //数据配置
    [self enableAttribute:_program0 attributeArray:@[@"position", @"textureCoordinate"]];
    

    glVertexAttribPointer([_program0 attributeIndex:@"position"], 2, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 4, NULL);
    glVertexAttribPointer([_program0 attributeIndex:@"textureCoordinate"], 2, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 4, (GLfloat *)NULL + 2);
    
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, _sourceImageTexture);//渲染不进去？
    glUniform1i([_program0 uniformIndex:@"imageTexture"], 2);
    glDrawArrays(GL_TRIANGLES, 0, 6);
    //没有渲染到
    
    
    glGenRenderbuffers(1, &_displayRenderbuffer);
    glBindRenderbuffer(GL_RENDERBUFFER, _displayRenderbuffer);
    [_context renderbufferStorage:GL_RENDERBUFFER fromDrawable:self.eaglLayer];
    glGenFramebuffers(1, &_displayFramebuffer);
    glBindFramebuffer(GL_FRAMEBUFFER, _displayFramebuffer);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                              GL_RENDERBUFFER, _displayRenderbuffer);
    
    [_program1 use];
    glBindFramebuffer(GL_FRAMEBUFFER, _displayFramebuffer);
    glClearColor(0.0, 0.0, 0.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT);
    [self viewPort];
    GLfloat attrArr2[] =
    {
        1.0 * scale, 1.0 * scale,     1.0, 0.0,
        1.0 * scale, -1.0 * scale,     1.0, 1.0,
        -1.0 * scale, -1.0 * scale,    0.0, 1.0,
        -1.0 * scale, -1.0 * scale,    0.0, 1.0,
        -1.0 * scale, 1.0 * scale,     0.0, 0.0,
        1.0 * scale, 1.0 * scale,    1.0, 0.0,
    };
    glGenBuffers(1, &_vbo1);
    glBindBuffer(GL_ARRAY_BUFFER, _vbo1);
    glBufferData(GL_ARRAY_BUFFER, sizeof(attrArr2), attrArr2, GL_STATIC_DRAW);
    
    [self enableAttribute:_program1 attributeArray:@[@"position", @"textureCoordinate"]];
    glVertexAttribPointer([_program1 attributeIndex:@"position"], 2, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 4, NULL);
    glVertexAttribPointer([_program1 attributeIndex:@"textureCoordinate"], 2, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 4, (GLfloat *)NULL + 2);
    
    glActiveTexture(GL_TEXTURE3);
    glBindTexture(GL_TEXTURE_2D, _outputFrameBufferTexture);///GPUImage中就是直接渲染原尺寸的纹理
    glUniform1i([_program1 uniformIndex:@"imageTexture"], 3);
    
    glDrawArrays(GL_TRIANGLES, 0, 6);
    
    glBindRenderbuffer(GL_RENDERBUFFER, _displayRenderbuffer);
    [_context presentRenderbuffer:GL_RENDERBUFFER];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    glFinish();
    //取出图片
    CGSize s = [UIImage imageNamed:targetImageName].size;
    CGSize size = CGSizeZero;
    size = CGSizeMake(s.width, s.height);//就是需要图片的size
    CGImageRef imageRef = [self newCGImageFromFramebufferContentsWithTargetImageSize:size];
    UIImage *image = [UIImage imageWithCGImage:imageRef];
    _imageView.image = image;
    _imageView.contentMode = UIViewContentModeScaleAspectFit;
}

///来自于GPUImage的代码
- (CGImageRef)newCGImageFromFramebufferContentsWithTargetImageSize:(CGSize)size {
    glBindFramebuffer(GL_FRAMEBUFFER, _outputFrameBuffer);
//    glViewport(0, 0, (int)size.width, (int)size.height);
    
    __block CGImageRef cgImageFromBytes;
    NSUInteger totalBytesForImage = (int)size.width * (int)size.height * 4;///图片所需要的字节数
    // It appears that the width of a texture must be padded out to be a multiple of 8 (32 bytes) if reading from it using a texture cache
    //如果使用纹理缓存读取纹理，纹理的宽度必须被填充为8(32字节)的倍数
    
    GLubyte *rawImagePixels;
    CGDataProviderRef dataProvider = NULL;
    
    
    rawImagePixels = (GLubyte *)malloc(totalBytesForImage);
    ///手动分配内存并且读取
    
    ///read 图片的size
    glReadPixels(0, 0, (int)size.width, (int)size.height, GL_RGBA, GL_UNSIGNED_BYTE, rawImagePixels);
    dataProvider = CGDataProviderCreateWithData(NULL, rawImagePixels, totalBytesForImage, zzzdataProviderReleaseCallbackFunc);///根据指针、字节，在内存中获取data
    
    CGColorSpaceRef defaultRGBColorSpace = CGColorSpaceCreateDeviceRGB();//颜色空间
    ///从数据中提取图片
    cgImageFromBytes = CGImageCreate((int)size.width, (int)size.height
                                     , 8, 32, 4 * (int)size.width, defaultRGBColorSpace, kCGBitmapByteOrderDefault | kCGImageAlphaLast, dataProvider, NULL, NO, kCGRenderingIntentDefault);
    
    //释放
    CGDataProviderRelease(dataProvider);
    CGColorSpaceRelease(defaultRGBColorSpace);
    
    return cgImageFromBytes;
}

- (void)setupImageTexture {//提供原图片尺寸的纹理 - _sourceImageTexture
    CGImageRef spriteImage = [UIImage imageNamed:targetImageName].CGImage;
    
    size_t width = CGImageGetWidth(spriteImage);
    size_t height = CGImageGetHeight(spriteImage);
    GLubyte *spriteData = (GLubyte *) calloc(width * height * 4, sizeof(GLubyte));
    CGContextRef spriteContext = CGBitmapContextCreate(spriteData, width, height, 8, width*4,
                                                       CGImageGetColorSpace(spriteImage), kCGImageAlphaPremultipliedLast);
    CGContextDrawImage(spriteContext, CGRectMake(0, 0, width, height), spriteImage);
    _sourceImageTexture =  [[self class] createTexture2DWithWidth:(int)width height:(int)height data:spriteData];

    CGContextRelease(spriteContext);
    free(spriteData);
}


- (void)setupOutputFrameBuffer {
    glGenFramebuffers(1, &_outputFrameBuffer);
    glBindFramebuffer(GL_FRAMEBUFFER, _outputFrameBuffer);

    CGImageRef spriteImage = [UIImage imageNamed:targetImageName].CGImage;
    size_t width = CGImageGetWidth(spriteImage) ;
    size_t height = CGImageGetHeight(spriteImage);
	_outputFrameBufferTexture =  [[self class] createTexture2DWithWidth:(int)width height:(int)height data:NULL];
    
    //关联纹理关联到当前的FBO上 关联无数据的帧缓存
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, _outputFrameBufferTexture, 0);///获得这个纹理的信息
}

///默认格式为RGBA
+ (GLuint)createTexture2DWithWidth:(GLsizei )width height:(GLsizei)height data:(void *)data {
    GLuint texture;
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
    glBindTexture(GL_TEXTURE_2D, 0);
    return texture;
}

@end

