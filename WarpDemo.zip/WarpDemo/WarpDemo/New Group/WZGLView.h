//
//  WZGLView.h
//  WarpDemo
//
//  Created by 李炜钊 on 2017/10/21.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>
#import "GLProgram.h"
#include <OpenGLES/ES2/gl.h>
#include <OpenGLES/ES2/glext.h>

@interface WZGLView : UIView
{
    GLProgram *_program0;
    GLuint _buffer0;
    GLuint _dataBuffer0;
    GLuint _texture0;
}

@property (nonatomic, weak) CAEAGLLayer *eaglLayer;
@property (nonatomic, strong) EAGLContext *context;

//整体
@property (nonatomic, assign) GLuint colorRenderBuffer;
@property (nonatomic, assign) GLuint colorFrameBuffer;

///个别
@property (nonatomic, strong) GLProgram *program0;
@property (nonatomic, assign) GLuint buffer0;
@property (nonatomic, assign) GLuint texture0;


void setupTexture(NSString *fileName, GLuint *textures, GLenum texture);
- (void)setupProgram:(GLProgram *)program attributeArray:(NSArray <NSString *>*)attributeArray;
- (void)enableAttribute:(GLProgram *)program attributeArray:(NSArray <NSString *>*)attributeArray;
- (void)update;
- (void)fitSizeWithProgram0Texture;
void dataProviderReleaseCallback (void *info, const void *data, size_t size);

@end
