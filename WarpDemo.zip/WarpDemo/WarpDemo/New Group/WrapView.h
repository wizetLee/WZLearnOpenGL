//
//  WrapView.h
//  WarpDemo
//
//  Created by admin on 31/10/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WrapView : UIView

@end
