//
//  WrapView.m
//  WarpDemo
//
//  Created by admin on 31/10/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "WrapView.h"
#import "GLProgram.h"
#include <OpenGLES/ES2/gl.h>
#include <OpenGLES/ES2/glext.h>
#import "WZGLView.h"

#define backgroundImageName @"15952016071513373913911529.png"//@"Simulator Screen Shot - iPhone 8 Plus - 2017-11-01 at 14.42.34.png"
#define wrapImageName @"24472016071513372170498279.png"//@"74172016103114541058969337.jpg"
//@"15952016071513373913911529.png"
//@"24472016071513372170498279.png"

#define Column (1000)
#define SizeOfVectorTextureCoordinate (Column * 2/*position :x, y*/ * 2/*texture: x, y*/ * 2/*两个点*/ + 4*2)
#define SizeOfIndices  (Column * 3/*位置*/ * 2/*个数*/)

typedef NS_ENUM(NSUInteger, VertorOriention) {
    VertorOriention_None,
    VertorOriention_Left,
    VertorOriention_Right,
};

@interface WrapView ()

{
    float new_arrBuffer[SizeOfVectorTextureCoordinate];
    int new_indices[SizeOfIndices];
    CGFloat targetY;//计算非线性方程极大值的依据   0~1
    CGFloat targetX;//计算偏移程度的依据
    CGFloat lastLocationX;
    
    BOOL updating;
}
@property (nonatomic, strong) CAEAGLLayer *eaglLayer;
@property (nonatomic, strong) EAGLContext *context;

@property (nonatomic, strong) GLProgram *programNormal;
@property (nonatomic, strong) GLProgram *programWrap;

@property (nonatomic, assign) GLuint renderbufferForImage;//图片的渲染缓存
@property (nonatomic, assign) GLuint framebufferForImage;//图片的帧缓存

@property (nonatomic, assign) GLuint framebufferForRender;//需要渲染的目标帧缓存
@property (nonatomic, assign) GLuint textureForRender;  //需要渲染的目标纹理句柄

@property (nonatomic, assign) GLuint textureForImage;   //渲染图片的纹理句柄
@property (nonatomic, assign) GLuint textureForbackGroundImage;   //渲染图片的纹理句柄

///图片的VBO
@property (nonatomic, assign) GLuint VBO0;
///变化的VBO
@property (nonatomic, assign) GLuint VBO1;
///变化的VBO 索引
@property (nonatomic, assign) GLuint index1;

@end

@implementation WrapView

#pragma mark -
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        CGSize size = [self fitSizeComparisonWithScreenBound:[UIImage imageNamed:backgroundImageName].size];
        self.frame = CGRectMake(0.0, 0.0, size.width, size.height);
        [self wzGLprelude];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self update];
}

- (void)dealloc {
    glDeleteBuffers(1, &_VBO1);
    glDeleteBuffers(1, &_VBO0);
    
    glDeleteFramebuffers(1, &_framebufferForRender);
    glDeleteFramebuffers(1, &_framebufferForImage);
    
    glDeleteTextures(1, &_textureForbackGroundImage);
    glDeleteTextures(1, &_textureForRender);
    glDeleteTextures(1, &_textureForImage);
}

- (void)update {
    
   NSArray * attributeStrs = @[@"position", @"textureCoordinate"];
    
//离屏渲染
    [_programWrap use];
    glBindFramebuffer(GL_FRAMEBUFFER, _framebufferForRender);
    [self clearColor];
    [self viewPort];
    //弯曲的
    glBindBuffer(GL_ARRAY_BUFFER, _VBO1);
    glVertexAttribPointer([_programWrap attributeIndex:@"position"], 2, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 4, NULL);
    glVertexAttribPointer([_programWrap attributeIndex:@"textureCoordinate"], 2, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 4, (float *)NULL + 2);
    [self enableAttribute:_programWrap attributeArray:attributeStrs];
    
    //将纹理绑定到帧缓存中
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, _textureForImage);
    //配置着色器采样器值
    glUniform1i([_programWrap uniformIndex:@"imageTexture"], 2);
    [self dataChangeAndDraw];
    
//屏幕内渲染
    [_programNormal use];
    glBindFramebuffer(GL_FRAMEBUFFER, _framebufferForImage);
    [self clearColor];
    [self viewPort];
    glBindBuffer(GL_ARRAY_BUFFER, _VBO0);
    
    attributeStrs = @[@"position", @"textureCoordinate", @"secondTextureCoordinate"];
    glVertexAttribPointer([_programNormal attributeIndex:@"position"], 2, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 5, NULL);
    glVertexAttribPointer([_programNormal attributeIndex:@"textureCoordinate"], 2, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 5, (GLfloat *)NULL + 3);
    glVertexAttribPointer([_programNormal attributeIndex:@"secondTextureCoordinate"], 2, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 5, (GLfloat *)NULL + 3);
    [self enableAttribute:_programNormal attributeArray:attributeStrs];
    
    glActiveTexture(GL_TEXTURE3);
    glBindTexture(GL_TEXTURE_2D, _textureForRender);///渲染到纹理中
    glUniform1i([_programNormal uniformIndex:@"sourceImage"], 3);
    
    glActiveTexture(GL_TEXTURE4);
    glBindTexture(GL_TEXTURE_2D, _textureForbackGroundImage);///渲染到纹理中
    glUniform1i([_programNormal uniformIndex:@"secondSourceImage"], 4);
    
    glUniform1f([_programNormal uniformIndex:@"alpha"], 1.0);
    glUniform1i([_programNormal uniformIndex:@"blendType"], 33);

    glDrawArrays(GL_TRIANGLES, 0, 6);
    
    [_context presentRenderbuffer:GL_RENDERBUFFER];
}

#pragma mark - Private
- (void)clearColor {
    glClearColor(0.0, 0.0, 0.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT);
}

- (void)wzGLprelude {
    [self setupLayer];
    [self setupContext];
    [self setupPrograms];

    [self destroyFramebuffer:&_framebufferForRender];
    [self destroyFramebuffer:&_framebufferForImage];
    [self destroyRenderbuffer:&_renderbufferForImage];
    
    [self setupRenderbuffer:&_renderbufferForImage];
    [_context renderbufferStorage:GL_RENDERBUFFER fromDrawable:self.eaglLayer];
    [self setupFramebuffer:&_framebufferForImage];
    glBindFramebuffer(GL_FRAMEBUFFER, _framebufferForImage);
    //关联渲染缓存到帧缓存
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                              GL_RENDERBUFFER, _renderbufferForImage);
    
    ////// 关联纹理到帧缓存中
    [self setupFramebuffer:&_framebufferForRender];
    
    CGSize targetSize = CGSizeMake([UIImage imageNamed:wrapImageName].size.width, [UIImage imageNamed:wrapImageName].size.height);
    [self attachTexture:&_textureForRender toFrameBuffer:&_framebufferForRender withTargetSize:targetSize];
    
    [self normalData];
    [self setupVBO0];
    [self setupVBO1];
    [self renderTextureWithImageName:wrapImageName texture:&_textureForImage];//把图片绘制到某个纹理当中
    [self renderTextureWithImageName:backgroundImageName texture:&_textureForbackGroundImage];//把图片绘制到某个纹理当中
}


- (void)setupVBO1 {
	glGenBuffers(1, &_VBO1);
    glGenBuffers(1, &_index1);
}

- (void)setupVBO0 {
    CGFloat scale = 1.0;
    GLfloat attrArr[] =
    {
        1.0 * scale, 1.0 * scale, 0,     1.0, 0.0,
        1.0 * scale, -1.0 * scale, 0,     1.0, 1.0,
        -1.0 * scale, -1.0 * scale, 0,    0.0, 1.0,
        -1.0 * scale, -1.0 * scale, 0,    0.0, 1.0,
        -1.0 * scale, 1.0 * scale, 0,     0.0, 0.0,
        1.0 * scale, 1.0 * scale, 0,     1.0, 0.0,
    };
    glGenBuffers(1, &_VBO0);
    glBindBuffer(GL_ARRAY_BUFFER, _VBO0);
    glBufferData(GL_ARRAY_BUFFER, sizeof(attrArr), attrArr, GL_STATIC_DRAW);
    
}

///关联纹理到帧缓存   使用的是目标图片的size
- (void)attachTexture:(GLuint *)texture toFrameBuffer:(GLuint *)frambuffer withTargetSize:(CGSize)tragetSize {
    if (!glIsTexture(*texture)) {
        glGenTextures(1, texture);
    }
    if (!glIsFramebuffer(*frambuffer)) {
        glGenFramebuffers(1, frambuffer);
    }
    
    glBindTexture(GL_TEXTURE_2D, *texture);
    glBindFramebuffer(GL_FRAMEBUFFER, *frambuffer);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, tragetSize.width, tragetSize.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, *texture, 0);
}

- (void)renderTextureWithImageName:(NSString*)fileName texture:(GLuint *)texture{
    // 1获取图片的CGImageRef
    CGImageRef spriteImage = [UIImage imageNamed:fileName].CGImage;
    
    if (!spriteImage) {
        NSLog(@"Failed to load image %@", fileName);
        exit(1);
    }
    
    // 2 读取图片的大小
    size_t width = CGImageGetWidth(spriteImage);
    size_t height = CGImageGetHeight(spriteImage);
    
    GLubyte *spriteData = (GLubyte *) calloc(width * height * 4, sizeof(GLubyte)); //rgba共4个byte
    
    CGContextRef spriteContext = CGBitmapContextCreate(spriteData, width, height, 8, width*4,
                                                       CGImageGetColorSpace(spriteImage), kCGImageAlphaPremultipliedLast);
    
    // 3在CGContextRef上绘图
    CGContextDrawImage(spriteContext, CGRectMake(0, 0, width, height), spriteImage);
    
    CGContextRelease(spriteContext);

    glEnable(GL_TEXTURE_2D);
    if (glIsTexture(*texture)) {
        
    } else {
        glGenTextures(1, texture);
    }
    glBindTexture(GL_TEXTURE_2D, *texture);
    
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    
    float fw = width, fh = height;
    //该格式决定颜色和深度的存储值
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, fw, fh, 0, GL_RGBA, GL_UNSIGNED_BYTE, spriteData);
    
    free(spriteData);
}

///启用数组内的顶点属性
- (void)enableAttribute:(GLProgram *)program attributeArray:(NSArray <NSString *>*)attributeArray {
    if ([attributeArray count]) {
        for (NSString *attributeName in attributeArray) {
            glEnableVertexAttribArray([program attributeIndex:attributeName]);
        }
    }
}

- (void)setupLayer {
//    [self setContentScaleFactor:[[UIScreen mainScreen] scale]];
    self.eaglLayer = (CAEAGLLayer *)self.layer;
    self.eaglLayer.opaque = true;
    // 设置描绘属性，在这里设置不维持渲染内容以及颜色格式为 RGBA8
    self.eaglLayer.drawableProperties = [NSDictionary dictionaryWithObjectsAndKeys:
                                         [NSNumber numberWithBool:false], kEAGLDrawablePropertyRetainedBacking, kEAGLColorFormatRGBA8, kEAGLDrawablePropertyColorFormat, nil];
}

- (void)setupContext {
    self.context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES2];
    [EAGLContext setCurrentContext:self.context];
}

- (void)setupPrograms {

    //背景 与 normal合并
    NSArray *attributeStrs = @[@"position", @"textureCoordinate", @"secondTextureCoordinate"];
    _programNormal = [[GLProgram alloc] initWithVertexShaderFilename:@"shaderColourModulationV" fragmentShaderFilename:@"shaderColourModulationF"];
    [self setupProgram:_programNormal attributeArray:attributeStrs];
    /*
     uniform:
         sourceImage
         secondSourceImage
         alpha
         blendType
     */
    
    //扭曲
    _programWrap = [[GLProgram alloc] initWithVertexShaderFilename:@"shaderDefaultV" fragmentShaderFilename:@"shaderDefaultF"];
    attributeStrs = @[@"position", @"textureCoordinate"];
    [self setupProgram:_programWrap attributeArray:attributeStrs];
}


///着色器属性绑定 以及 gl程序的链接
- (void)setupProgram:(GLProgram *)program attributeArray:(NSArray <NSString *>*)attributeArray {
    
    if ([attributeArray count]) {
        for (NSString *attributeName in attributeArray) {
            [program addAttribute:attributeName];
        }
    }
    
    if (!program.initialized)
    {
        if (![program link]) {
            NSString *progLog = [program programLog];
            NSLog(@"Program link log: %@", progLog);
            NSString *fragLog = [program fragmentShaderLog];
            NSLog(@"Fragment shader compile log: %@", fragLog);
            NSString *vertLog = [program vertexShaderLog];
            NSLog(@"Vertex shader compile log: %@", vertLog);
            program = nil;
            NSAssert(NO, @"Filter shader link failed");
        }
    }
}

- (void)destroyFramebuffer:(GLuint *)framebufferHandle {
    glDeleteFramebuffers(1, framebufferHandle);
    *framebufferHandle = 0;
}
- (void)destroyRenderbuffer:(GLuint *)renderbufferHandle {
    glDeleteRenderbuffers(1, renderbufferHandle);
    *renderbufferHandle = 0;
}

- (void)setupFramebuffer:(GLuint *)framebufferHandle {
    glGenFramebuffers(1, framebufferHandle);
    glBindFramebuffer(GL_FRAMEBUFFER, *framebufferHandle);
}

- (void)setupRenderbuffer:(GLuint *)renderbufferHandle {
    glGenRenderbuffers(1, renderbufferHandle);
    glBindRenderbuffer(GL_RENDERBUFFER, *renderbufferHandle);
}

- (CGSize)fitSizeComparisonWithScreenBound:(CGSize)targetSize {
    CGSize screenSize = [UIScreen mainScreen].bounds.size;
    CGSize imageSize = targetSize;
    CGSize fitSize = targetSize;
    if (imageSize.height != 0.0) {            //宽高比
        CGFloat whRate = imageSize.width / imageSize.height;
        //宽>高
        if (whRate > 1.0) {
            if (imageSize.width > screenSize.width) {
                fitSize.width = screenSize.width;
                fitSize.height = screenSize.width / imageSize.width * imageSize.height;
                
            }
            if (fitSize.height > screenSize.height) {
                fitSize.width = screenSize.height / fitSize.height * fitSize.width;
                fitSize.height = screenSize.height;
                
            }
        } else {
            
            //宽<高
            if (imageSize.height > screenSize.height) {
                fitSize.height = screenSize.height;
                fitSize.width = screenSize.height / imageSize.height * imageSize.width;
            }
            if (fitSize.width > screenSize.width) {
                fitSize.height = screenSize.width / fitSize.width * fitSize.height;
                fitSize.width = screenSize.width;
            }
        }
    }
    
    return fitSize;
}

//裁减和剪切
- (void)viewPort {
    //视图放大倍数
    CGFloat scale = [UIScreen mainScreen].scale;
    //设置视口
    glViewport(0.0
               , 0.0
               , self.frame.size.width * scale
               , self.frame.size.height * scale);
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}



+ (Class)layerClass {
    return [CAEAGLLayer class];
}

#pragma mark - 计算
- (void)normalData {
    targetY = 0.0;
    targetX = 0.0;
    updating = false;
    lastLocationX = 0.0;
    
    {
        int tmpIndex = 0;
        int stride = 4;//只保存顶点坐标xy 纹理坐标xy
        CGFloat yfloat = (Column * 1.0);
        CGFloat multiple = 2.0;
        float *arr = (float *)new_arrBuffer;
        ///顶点坐标 纹理坐标
        for (int j = 0; j < Column + 1; j++) {
            for (int i = 0; i < 2; i++) {//2个点为顶点坐标 另外两个点为纹理坐标
                CGFloat positionX = i;
                CGFloat positionY =  j / yfloat;
                
                CGFloat textureX = i;
                CGFloat textureY = j / yfloat;
                
                arr[tmpIndex + 0] = positionX * multiple - 1.0;
                arr[tmpIndex + 1] = positionY * multiple - 1.0;
                
                arr[tmpIndex + 2] = textureX;
                arr[tmpIndex + 3] = 1.0 - textureY;//textureY; //纹理坐标跟position坐标Y翻转
//                arr[tmpIndex + 3] = textureY;//不用翻转了 上一个zhuo'se'q
                tmpIndex += stride;
            }
        }
        stride = 6;
        tmpIndex = 0;
        ///索引
        for (int i = 0; i < Column; i++) {
            new_indices[tmpIndex + 0] = 1 + i*2;
            new_indices[tmpIndex + 1] = 3 + i*2;
            new_indices[tmpIndex + 2] = 2 + i*2;
            new_indices[tmpIndex + 3] = 2 + i*2;
            new_indices[tmpIndex + 4] = 0 + i*2;
            new_indices[tmpIndex + 5] = 1 + i*2;
            tmpIndex += stride;
        }
    }
    [self gestures];
}

- (void)gestures {
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)];
    [self addGestureRecognizer:pan];
}

- (void)pan:(UIPanGestureRecognizer *)pan {
    if (updating) { return;}
    updating = true;
    ///区分方向
    if (pan.state == UIGestureRecognizerStateBegan) {
        lastLocationX = [pan locationInView:pan.view].x;//拾获最初的角标
    } else if (pan.state == UIGestureRecognizerStateChanged) {
        //        CGPoint translation = [pan translationInView:pan.view];
        //        NSLog(@"%@", NSStringFromCGPoint(translation));
        
        CGFloat result = [pan translationInView:pan.view].x - lastLocationX;//方向判别
        lastLocationX = [pan translationInView:pan.view].x;//更新位置
        if (result > 0) {
            //向右
            targetX = 0.003;
        } else if (result < 0) {
            //向左
            targetX = -0.003;
        } else {
            //不变
            targetX = 0.0;
        }
        
        /**
         translation.x < 0    向左
         translation.y < 0    向上
         **/
        CGPoint curPoint = [pan locationInView:pan.view];
        targetY =  curPoint.y / self.bounds.size.height;//iOS 设备坐标下的0~1.0
        
        //数据范围
        if (targetY < 0) {targetY = 0.0;}
        if (targetY > 1) {targetY = 1.0;}
        
    } else if (pan.state == UIGestureRecognizerStateEnded) {
        
    }
    [self update];
    updating = false;
}

- (void)dataChangeAndDraw {
    {//--------------point : 计算偏移量
        CGFloat tmpTargetY = 1.0 - targetY;//取反得到纹理坐标系中的点
        
        ///手势对坐标的压缩量
        float xCompreess = 0.0;
        //计算偏移值
        int tmpIndex = 0;
        int stride = 4;//只保存顶点坐标xy 纹理坐标xy
        for (int j = 0; j < Column + 1; j++) {
            for (int i = 0; i < 2; i++) {//2个点为顶点坐标 另外两个点为纹理坐标
                //将[0.0, 1.0]区间映射到[-PI, PI]区间上
                xCompreess = j / (Column * 1.0);//0~1.0
                xCompreess = xCompreess * 2 * M_PI ;//0~2PI
                xCompreess = xCompreess - M_PI;//-PI~PI
                
                CGFloat tmpY = tmpTargetY;
                tmpY = tmpY * 2 * M_PI;//映射到[-PI, PI]区间上
                tmpY = tmpY - M_PI;
                
                //作差 得到 图形偏移
                //NSLog(@"图形偏移~%f", cos(xCompreess - tmpY) + 1);
                
                CGFloat degree = xCompreess - tmpY;
                if (degree > M_PI) {
                    degree = M_PI;
                } else if (degree < -M_PI) {
                    degree = -M_PI;
                }
                
                CGFloat tmpComPress = sqrt((cos(degree) + 1)) * targetX;
                
                new_arrBuffer[tmpIndex + 0] = new_arrBuffer[tmpIndex + 0] + tmpComPress;//只修改X坐标  根据j代入相应的非线性方程中 得到偏移量
                tmpIndex += stride;
            }
        }
    }
    
    ///打印数据
//        for(int i = 0 ; i < SizeOfVectorTextureCoordinate ; i++) {if (i % 4 == 0) {printf("\n"); }
//            printf("%f ", new_arrBuffer[i]);
//        }//    printf("\n--------------\n");
//        for(int i = 0 ; i < Column * 3/*位置*/ * 2/*个数*/ ; i++) {if (i % 3 == 0) { printf("\n"); }
//            printf("%d ", new_indices[i]);
//        }printf("\n--------------\n");
    
    
    glBindBuffer(GL_ARRAY_BUFFER, _VBO1);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * (SizeOfVectorTextureCoordinate) , new_arrBuffer, GL_DYNAMIC_DRAW);
    
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _index1);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(GLint)*SizeOfIndices, new_indices, GL_STATIC_DRAW);
    
    glDrawElements(GL_TRIANGLES, SizeOfIndices, GL_UNSIGNED_INT, 0);//绘制
}





@end
