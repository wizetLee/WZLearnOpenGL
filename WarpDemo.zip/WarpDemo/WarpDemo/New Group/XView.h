//
//  XView.h
//  WarpDemo
//
//  Created by admin on 10/11/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XView : UIView

@end
