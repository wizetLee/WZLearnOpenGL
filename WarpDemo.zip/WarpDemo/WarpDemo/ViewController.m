//
//  ViewController.m
//  WarpDemo
//
//  Created by admin on 20/10/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "ViewController.h"
#import "NView.h"
#import "MView.h"
#import "OView.h"
#import "PView.h"
#import "TView.h"
#import "WrapView.h"
@interface ViewController ()

//@property (nonatomic, strong) UIButton *btn;
//@property (nonatomic, assign) NSInteger number;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    NView *tmpView = [[NView alloc] initWithFrame: self.view.bounds];
//    MView *tmpView = [[MView alloc] initWithFrame: self.view.bounds];
//    OView *tmpView = [[OView alloc] initWithFrame: self.view.bounds];
//    PView *tmpView = [[PView alloc] initWithFrame: self.view.bounds];
    
    TView *tmpView = [[TView alloc] initWithFrame: self.view.bounds];
//    WrapView *tmpView = [[WrapView alloc] initWithFrame: self.view.bounds];
    [self.view addSubview:tmpView];
    tmpView.backgroundColor = [UIColor orangeColor];
    tmpView.center = self.view.center;
//    _btn = [[UIButton alloc] initWithFrame:CGRectMake(0.0, 2.0, 100.0, 44.0)];
//    [self.view addSubview:_btn];
//    _number = 0;
//    [_btn addTarget:self action:@selector(clicked:) forControlEvents:UIControlEventTouchUpInside];
//    [_btn setTitle:@"NView" forState:UIControlStateNormal];
//    _btn.backgroundColor = [UIColor yellowColor];
//    [_btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
 
}

//- (void)clicked:(UIButton *)sender {
//    _number++;
//    for (UIView *view in self.view.subviews) {
//        if (view == sender) {
//
//        } else {
//            [view removeFromSuperview];
//        }
//    }
//
//    if (_number == 3) {_number = 0;}
//    if (_number == 0) {
//        [_btn setTitle:@"NView" forState:UIControlStateNormal];
//
//        NView *tmpView = [[NView alloc] initWithFrame: self.view.bounds];
//        [self.view addSubview:tmpView];
//    } else if (_number == 1) {
//        MView *tmpView = [[MView alloc] initWithFrame: self.view.bounds];
//        [self.view addSubview:tmpView];
//         [_btn setTitle:@"MView" forState:UIControlStateNormal];
//    } else if (_number == 2) {
//        OView *tmpView = [[OView alloc] initWithFrame: self.view.bounds];
//        [self.view addSubview:tmpView];
//        [_btn setTitle:@"OView" forState:UIControlStateNormal];
//    }
//
//    [self.view bringSubviewToFront:sender];
//}




@end
